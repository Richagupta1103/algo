from LinkedList import LinkedList


def kth_to_last(ll, k):
    runner = current = ll.head
    for i in range(k):
        if runner is None:
            return None
        runner = runner.next

    while runner:
        current = current.next
        runner = runner.next

    return current

ll = LinkedList()
ll.generate(10, 0, 99)
print(ll)
print(kth_to_last(ll, 3))

# from LinkedList import LinkedList
#
# def kthToLast(ll,k):
#     p1=p2=ll.head
#     for i in range(k):
#         p1=p1.next
#     while p1:
#         p1=p1.next
#         p2=p2.next
#     print p2
#
# ll=LinkedList()
# ll.generate(10,0,100)
# print ll
# kthToLast(ll,4)