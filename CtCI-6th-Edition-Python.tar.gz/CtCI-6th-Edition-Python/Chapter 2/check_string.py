


def all_same(items):
    return all(x == items[0] for x in items)

def checkString(s):
    dict_of_words = {}
    for word in s:
        if word in dict_of_words:
            dict_of_words[word]+=1
        else:
            dict_of_words[word]=1
    if len(set(dict_of_words.values()))==1:
        n= len(dict_of_words)
        div_str = [s[i:i+n] for i in range(0, len(s), n)]
        print div_str
        if all_same(div_str):
            return True
        return False
    return False

if checkString('abcdeabcdeabcde'):
    print 'true'
else:
    print 'false'
