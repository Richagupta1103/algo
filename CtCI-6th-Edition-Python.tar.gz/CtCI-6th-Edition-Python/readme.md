##Python Solutions to Cracking the Coding Interview 6th Edition

To run the programs, just use the `python filename.py` command.

The test cases are included in the solution files.